#ifndef _Pan_Tilt_H
#define _Pan_Tilt_H

#include "APP\Math\Vect\Vect.h"
#include "My_Flag.h"
#include "sys.h"

/* 题目标号 */
enum Question_num {
    Question_11,       //将弹丸射出
    Question_12,       //200~300mm中心线处，偏差不少于50cm
    Question_13,       //输入角度和距离，按靶环数计分
    Question_21,       //任意放置目标，自动开炮
    Question_22,       //往返运动，过程中开炮
    Question_23,       //其他
    Gyro_calibrate,    //矫正陀螺仪
    charging           //充电中
};

/* 题目是否开始 */
enum Question_state
{
    adjust,   //调整模式
    fire,     //开火
    finish    //发射完成
};


/* 电磁炮信息 */
typedef struct
{
    //炮台姿态
    float X_Angle;
    float Y_Angle;

    //炮台目标姿态
    float Target_X_Angle;
    float Target_Y_Angle;
    
    //靶子目标角度和长度
    float Target_Angle;
    float Target_Length;

    enum Question_num Question; //当前题目
    enum Question_state State;  //是否运行
}sPan_Tilt_Typedef;

extern sPan_Tilt_Typedef Pan_Tilt;     //小车信息
/**********************************************
* 电磁炮参数初始化
**********************************************/
void Pan_Tilt_Param_Init(void);

/**********************************************
* 更新电磁炮信息
**********************************************/
void Pan_Tilt_Update(float x, float y);

/**********************************************
* 设置目标点
**********************************************/
void Pan_Tilt_Set_Target(float Target_Angle, float Target_Length);

/**********************************************
* 控制炮台运动
**********************************************/
void Pan_Tilt_Control(void);

/**********************************************
* 炮台复位
**********************************************/
void Pan_Tilt_Reset(void); 

/**********************************************
* 炮台校零
**********************************************/
void Pan_Tilt_Calibrate(void);

#endif /* _Pan_Tilt_H */

